﻿#if DEBUG
using MockIAPLib;
using Store = MockIAPLib;
#else
using Windows.ApplicationModel.Store;
#endif


using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Navigation;
using Microsoft.Phone.Controls;
using Microsoft.Phone.Shell;
using WindowsPhoneInAppPurchaseDemo.Resources;
using Windows.ApplicationModel.Store;

namespace WindowsPhoneInAppPurchaseDemo
{
    public partial class MainPage : PhoneApplicationPage
    {
        int tokenCount = 0;
        // Constructor
        public MainPage()
        {
            InitializeComponent();

            // Sample code to localize the ApplicationBar
            //BuildLocalizedApplicationBar();
        }

        private async void buttonPurchase_Click(object sender, RoutedEventArgs e)
        {
#if DEBUG
            MockIAPLib.ListingInformation listings = await MockIAPLib.CurrentApp.LoadListingInformationByProductIdsAsync(
                                    new string[] { "1 token"});
#else
            ListingInformation listings = await CurrentApp.LoadListingInformationByProductIdsAsync(
                                    new string[] { "1 token"});
#endif
            if (checkBoxTokens.IsChecked == true)
            {
#if DEBUG
                await MockIAPLib.CurrentApp.RequestProductPurchaseAsync(listings.ProductListings.ToList()[0].Value.ProductId, false);
#else
                await CurrentApp.RequestProductPurchaseAsync(listings.ProductListings.ToList()[0].Value.ProductId, false);
#endif

                CompleteFulfillMent();
            }
            textBoxCount.Text = tokenCount.ToString();
        }


        private void CompleteFulfillMent()
        {
            #if DEBUG
            var productLicenses = MockIAPLib.CurrentApp.LicenseInformation.ProductLicenses;
            MockIAPLib.ProductLicense tokenLicense = productLicenses["1 token"];
#else
            var productLicenses = CurrentApp.LicenseInformation.ProductLicenses;
            ProductLicense tokenLicense = productLicenses["1 token"];
#endif
            if (tokenLicense.IsConsumable && tokenLicense.IsActive)
            {
                tokenCount += 1;
#if DEBUG
                MockIAPLib.CurrentApp.ReportProductFulfillment(tokenLicense.ProductId);
#else
                CurrentApp.ReportProductFulfillment(tokenLicense.ProductId);
#endif
            }

        }

        

        // Sample code for building a localized ApplicationBar
        //private void BuildLocalizedApplicationBar()
        //{
        //    // Set the page's ApplicationBar to a new instance of ApplicationBar.
        //    ApplicationBar = new ApplicationBar();

        //    // Create a new button and set the text value to the localized string from AppResources.
        //    ApplicationBarIconButton appBarButton = new ApplicationBarIconButton(new Uri("/Assets/AppBar/appbar.add.rest.png", UriKind.Relative));
        //    appBarButton.Text = AppResources.AppBarButtonText;
        //    ApplicationBar.Buttons.Add(appBarButton);

        //    // Create a new menu item with the localized string from AppResources.
        //    ApplicationBarMenuItem appBarMenuItem = new ApplicationBarMenuItem(AppResources.AppBarMenuItemText);
        //    ApplicationBar.MenuItems.Add(appBarMenuItem);
        //}
    }
}